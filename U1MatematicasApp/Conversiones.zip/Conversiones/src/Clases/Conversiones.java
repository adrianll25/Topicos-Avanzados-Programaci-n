/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author adria
 */
public class Conversiones {
    public static float Celsius_Farenheit ( float Farenheit ){
       return (Farenheit * 1.8f) + 32;
    }
    
    public static float Farenheit_Celsius( float Celsius ){
        return ( Celsius - 32 ) / 1.8f;
    }
    
    public static double Metros_Yardas ( double Yardas ){
        return ( Yardas * 0.09144 );
    }
    
    public static double Yardas_Metros ( double Metros ){
        return ( Metros / 0.09144 );
    }
    
    public static long Binario_Decimal (String binario) {
  
     long Decimal = 0;
     int Posicion = 0;
  
     for ( int x = binario.length() - 1; x >= 0; x-- ) {
      
           short digito = 1;
           
      if ( binario.charAt(x) == '0' ) {
            digito = 0;
      }

      double multiplicador = Math.pow( 2, Posicion );
      Decimal += digito * multiplicador;
      Posicion++;
  }
     
  return Decimal;
}
    public static String Decimal_Binario (long decimal) {
	if ( decimal <= 0 ) {
		return "0";
	}
	StringBuilder binario = new StringBuilder();
        
	while ( decimal > 0 ) {
		short residuo = ( short ) ( decimal % 2 );
		decimal = decimal / 2;
		
		binario.insert( 0, String.valueOf( residuo ) );
	}
	return binario.toString();
}
    
}
