
drop table Kardex;
drop table Alumnos;
drop table Materia;
