
package mx.tecnm.beans;


public interface DatosModificadosListener {
    
    public void DatosModificadosPrisma ( DatosModificadosEvent ev ) ;
        
    
}
