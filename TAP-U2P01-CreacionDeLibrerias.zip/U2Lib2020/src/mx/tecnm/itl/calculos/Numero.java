/* -----------------------------------------------------------------------------
                       INSTITUTO TECNOLOGICO DE LA LAGUNA
                     INGENIERIA EN SISTEMAS COMPUTACIONALES
                       TOPICOS AVANZADOS DE PROGRAMACION "B"

                   SEMESTRE: ENE-JUN/2013    HORA: 10-11 HRS

 Clase numero que sirve de auxiliar para la formula General en la clase Matematica-


  Archivo     : Numero.java
  Autor       : jesus Adrian Lopez Luevanos 18131253
  Fecha       : 02/09/2020
  Compilador  : Java j2SE V1.8.0
  Descripción : Clase sencilla de apoyo para la realizacion de la formula general 
                es de tipo String su contenido.

--------------------------------------------------------------------------------
Ultima Modificacion: 
Fecha: 
Modifico: 
Motivo: 
*/

package mx.tecnm.itl.calculos;
/**
 *
 * @author adria
 */
public class Numero {
    String num;
}
