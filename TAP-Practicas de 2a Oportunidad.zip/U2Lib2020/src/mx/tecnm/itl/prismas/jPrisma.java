
package mx.tecnm.itl.prismas;

/**
 *
 * @author adria
 */
public interface jPrisma {
    
    public double areaBase    ( );
    public double areaLateral ( );
    public double areaTotal   ( );
    public double Volumen     ( );
        
    }

